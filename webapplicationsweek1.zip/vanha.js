import "./styles.css";

if (document.readyState !== "loading") {
  // Document ready, executing:
  console.log("Document ready, executing");
  initializeCode();
} else {
  // Document was not ready, executing when loaded
  document.addEventListener("DOMContentLoaded", function () {
    console.log("Document ready, executing after a wait");
    initializeCode();
  });
}

function initializeCode() {
  console.log("Initializing");
  renderCells(); // finish the table
}

// The function below finds the table initialized in index.html and fills it with cells.
// The final table will be of size 5x5.
function renderCells() {
  var tbl = document.getElementById("board");

  for (var i = 0; i < 5; i++) {
    // Creating 5 rows
    var tr = tbl.insertRow();
    for (var j = 0; j < 5; j++) {
      // Creating 5 columns as well
      // Columns are created by inserting 5 cells into each row
      var td = tr.insertCell();
      // Make cells clickable
      var player = "X"; // Player X starts the game.
      var hits = 0; // Number of clicks
      td.addEventListener("click", function () {
        var lastround = player;
        player = fillCell(this, player); // when cell is clicked -> fill

        // The player ID, whose turn it is next, is shown on the page
        document.getElementById("samplepar").innerHTML = player;
        hits++;
        if (hits > 8) {
          // When there's been 5 or more turns
          var win = calculateWinCondition(lastround);
          if (win === 1) {
            document.getElementById("winnertext").innerHTML =
              lastround + " won!";
            // End game
            // Suggest a new game
          }
        }
      });
    }
  }
}

function fillCell(cell, player) {
  // Player 1: X, player 2: O.
  if (cell.innerHTML === "") {
    // If the on-clicked cell is empty
    if (player === "X") {
      cell.appendChild(document.createTextNode("X"));
      player = "O";
    } else {
      cell.appendChild(document.createTextNode("O"));
      player = "X";
    }
  } else {
    alert("Select another cell!");
  }
  //alert("Player N wins!");
  return player;
}
function calculateWinCondition(player) {
  var tbl = document.getElementById("board");
  var i, j, row, col;
  for (i = 0; (row = tbl.rows[i]); i++) {
    //iterate through rows
    //rows would be accessed using the "row" variable assigned in the for loop
    for (j = 0; (col = row.cells[j]); j++) {
      //iterate through columns
      //columns would be accessed using the "col" variable assigned in the for loop
    }
  }
}

function calculateWinCondition(player) {
  var tbl = document.getElementById("board");
  var playerno;
  if (player === "X") {
    playerno = 1;
  } else {
    playerno = 2;
  }
  var result = true;
  var win = 0;
  var i, j;
  // Ongelmana tablen iteroiminen
  // pitää tehdä .rows:in ja .cells:in avulla?

  // Check the 5 rows and columns in one loop:
  for (i = 0; i < 5; i++) {
    result = true;
    // HORIZONTALLY:
    for (j = 0; j < 5; j++) {
      // check the j cells of the #i row
      result = result && tbl[i][j].innerHTML === player;
      // if any of the cells is not equal to player symbol, this Boolean value will be false.
    }
    if (result === true) {
      win++;
      alert("Player " + playerno + " wins!");
      return win;
    }
    result = true;
    // VERTICALLY:
    for (j = 0; j < 5; j++) {
      // check the j cells of the #i column
      result = result && tbl[j][i].innerHTML === player;
    }
    if (result === true) {
      win++;
      alert("Player " + playerno + " wins!");
      return win;
    }
  }

  // DIAGONALS:

  // Check the diagonal from left to right:
  result = true;
  for (j = 0; j < 5; j++) {
    result = result && tbl[j][j].innerHTML === player;
  }
  if (result === true) {
    win++;
    alert("Player " + playerno + " wins!");
    return win;
  }

  // Check the diagonal from right to left:
  result = true;
  for (j = 0; j < 5; j++) {
    result = result && tbl[4 - j][j].innerHTML === player;
  }
  if (result === true) {
    win++;
    alert("Player " + playerno + " wins!");
    return win;
  }
  // If none of the cases were true, the function returns 0
  return win;
}
